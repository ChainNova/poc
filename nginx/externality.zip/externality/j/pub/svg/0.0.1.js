;(function(factory){
  if (typeof define === 'function' && define.amd) {
    define([], factory)
  }
})(function() {

})
